# StockSync Warehouse App

A working browser-based prototype for warehouse stock management.

Features:
- Stock In entry
- Stock Out entry
- Automatic stock balance
- Opening + In - Out calculation
- Physical stock count and discrepancy detection
- Invoice tracker
- Inter-warehouse transfer tracker
- Dashboard
- CSV export
- Data saved automatically in the browser using localStorage

How to use:
1. Open index.html in a browser.
2. Start from Stock > Stock In / Stock Out.
3. Use Stock Balance (Auto) to see calculated quantities.
4. Use Physical Count to enter the actual warehouse count and identify discrepancies.

This version is a local prototype: it does not have a server/database or multi-user login yet. Data is stored on the device/browser where it is used.
